package com.example.productapi.controller;

import com.example.productapi.model.Product;
import com.example.productapi.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
  private final ProductService productService;

  public ProductController(ProductService productService) {
    this.productService = productService;
  }

  @GetMapping
  public List<Product> getAll() {
    return productService.findAll();
  }

  @GetMapping("/{id}")
  public Product getById(@PathVariable Long id) {
    return productService.findById(id);
  }

  @PostMapping
  public ResponseEntity<Product> create(@Valid @RequestBody Product product) {
    Product created = productService.create(product);
    return ResponseEntity.created(URI.create("/api/products/" + created.getId())).body(created);
  }

  @PutMapping("/{id}")
  public Product update(@PathVariable Long id, @Valid @RequestBody Product product) {
    return productService.update(id, product);
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> delete(@PathVariable Long id) {
    productService.delete(id);
    return ResponseEntity.noContent().build();
  }
}
