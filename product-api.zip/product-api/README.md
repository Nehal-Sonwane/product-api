# Product API (MySQL + Maven)

Simple Spring Boot RESTful API that performs CRUD on a `Product` resource with:
- JPA persistence (MySQL)
- Bean Validation (JSR 380) with custom messages
- Global exception handling (`@ControllerAdvice`)
- JWT Authentication (basic implementation)
- OpenAPI/Swagger UI for docs and testing

## Requirements
- Java 17+
- Maven
- MySQL

## Build & Run
1. Create a MySQL database named `productdb` and update `src/main/resources/application.properties` if needed.
2. Build the project:
   ```bash
   mvn clean package
   ```
3. Run:
   ```bash
   java -jar target/product-api-0.0.1-SNAPSHOT.jar
   ```

The server starts on `http://localhost:8080`.

## Auth
- `POST /api/auth/login` -> `{ "username": "user", "password": "password" }` returns `{ token }`
- Use `Authorization: Bearer <token>` to access `/api/products` endpoints.

## Swagger UI
`http://localhost:8080/swagger-ui.html` or `http://localhost:8080/swagger-ui/index.html`

